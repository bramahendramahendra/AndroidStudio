var searchData=
[
  ['maxrects',['maxRects',['../classknoxremotedesktop_1_1DirtyRegion.html#a65b638db44b5b39191e0d72123d9ccc8',1,'knoxremotedesktop::DirtyRegion']]]
];
