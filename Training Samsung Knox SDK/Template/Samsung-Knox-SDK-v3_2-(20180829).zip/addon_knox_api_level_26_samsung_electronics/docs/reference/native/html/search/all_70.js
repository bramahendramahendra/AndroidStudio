var searchData=
[
  ['pixelformatdetail',['PixelFormatDetail',['../structknoxremotedesktop_1_1PixelFormatDetail.html',1,'knoxremotedesktop']]]
];
