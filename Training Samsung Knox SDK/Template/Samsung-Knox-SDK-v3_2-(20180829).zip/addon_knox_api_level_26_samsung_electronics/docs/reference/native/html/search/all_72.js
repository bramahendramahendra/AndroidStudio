var searchData=
[
  ['redlength',['redlength',['../structknoxremotedesktop_1_1PixelFormatDetail.html#a370e9d8250b35b1f717a71a3737c73d5',1,'knoxremotedesktop::PixelFormatDetail']]],
  ['redoffset',['redoffset',['../structknoxremotedesktop_1_1PixelFormatDetail.html#a5c1e26d5565b29732f007ab2f4c89357',1,'knoxremotedesktop::PixelFormatDetail']]]
];
