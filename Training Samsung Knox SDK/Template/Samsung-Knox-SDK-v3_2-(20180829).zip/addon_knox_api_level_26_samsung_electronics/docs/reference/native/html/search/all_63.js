var searchData=
[
  ['capturescreen',['captureScreen',['../classknoxremotedesktop_1_1IRemoteDesktop.html#a0ab5a0cf162a91c5e69abeed90f8ba09',1,'knoxremotedesktop::IRemoteDesktop']]]
];
