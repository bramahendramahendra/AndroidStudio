var searchData=
[
  ['greenlength',['greenlength',['../structknoxremotedesktop_1_1PixelFormatDetail.html#a87f98032962d81ee015a6a0c56ec6290',1,'knoxremotedesktop::PixelFormatDetail']]],
  ['greenoffset',['greenoffset',['../structknoxremotedesktop_1_1PixelFormatDetail.html#ab334f70ccc320d17dc86a28730954964',1,'knoxremotedesktop::PixelFormatDetail']]]
];
