var searchData=
[
  ['bluelength',['bluelength',['../structknoxremotedesktop_1_1PixelFormatDetail.html#aeb798caab6629e147478319285d2591f',1,'knoxremotedesktop::PixelFormatDetail']]],
  ['blueoffset',['blueoffset',['../structknoxremotedesktop_1_1PixelFormatDetail.html#a7afad9374c4aab4d1fbe2a15396ade47',1,'knoxremotedesktop::PixelFormatDetail']]],
  ['bpp',['bpp',['../structknoxremotedesktop_1_1PixelFormatDetail.html#a9557bebcc969ba20502ba9d377e085dc',1,'knoxremotedesktop::PixelFormatDetail']]]
];
