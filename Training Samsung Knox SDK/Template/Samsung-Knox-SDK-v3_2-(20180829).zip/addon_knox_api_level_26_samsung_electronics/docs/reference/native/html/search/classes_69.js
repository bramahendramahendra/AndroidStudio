var searchData=
[
  ['iremotedesktop',['IRemoteDesktop',['../classknoxremotedesktop_1_1IRemoteDesktop.html',1,'knoxremotedesktop']]],
  ['iremotedesktoplistener',['IRemoteDesktopListener',['../classknoxremotedesktop_1_1IRemoteDesktopListener.html',1,'knoxremotedesktop']]]
];
