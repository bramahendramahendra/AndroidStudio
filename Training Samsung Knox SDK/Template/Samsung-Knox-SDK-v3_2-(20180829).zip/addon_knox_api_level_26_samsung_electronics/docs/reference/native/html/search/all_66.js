var searchData=
[
  ['fdtype',['FDType',['../namespaceknoxremotedesktop.html#a01c73ba2fbebc2395aae6198eb87a416',1,'knoxremotedesktop']]]
];
