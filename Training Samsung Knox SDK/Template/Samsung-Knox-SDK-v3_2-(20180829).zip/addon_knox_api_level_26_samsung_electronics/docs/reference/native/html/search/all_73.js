var searchData=
[
  ['screenchanged',['screenChanged',['../classknoxremotedesktop_1_1IRemoteDesktopListener.html#a737ab352cec0a7dc249da5519a8e14b0',1,'knoxremotedesktop::IRemoteDesktopListener']]],
  ['setlistener',['setListener',['../classknoxremotedesktop_1_1IRemoteDesktop.html#af22e75002f52d837cfc9d9589647ddb9',1,'knoxremotedesktop::IRemoteDesktop']]],
  ['setscreeninfo',['setScreenInfo',['../classknoxremotedesktop_1_1IRemoteDesktop.html#aeb13652779ac87ce9de9a8155f6dc60b',1,'knoxremotedesktop::IRemoteDesktop']]]
];
