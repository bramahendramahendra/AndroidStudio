var searchData=
[
  ['alphalength',['alphalength',['../structknoxremotedesktop_1_1PixelFormatDetail.html#a2e62bca1625dfeefebd537dd0678627d',1,'knoxremotedesktop::PixelFormatDetail']]],
  ['alphaoffset',['alphaoffset',['../structknoxremotedesktop_1_1PixelFormatDetail.html#a4cfaeee3077ff3609b0d7a5aab4e5a83',1,'knoxremotedesktop::PixelFormatDetail']]]
];
