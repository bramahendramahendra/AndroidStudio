var searchData=
[
  ['dirtyrects',['dirtyRects',['../classknoxremotedesktop_1_1DirtyRegion.html#a46d58ad2c718f79613f9ad1b02d64c3d',1,'knoxremotedesktop::DirtyRegion']]],
  ['dirtyregion',['DirtyRegion',['../classknoxremotedesktop_1_1DirtyRegion.html',1,'knoxremotedesktop']]]
];
