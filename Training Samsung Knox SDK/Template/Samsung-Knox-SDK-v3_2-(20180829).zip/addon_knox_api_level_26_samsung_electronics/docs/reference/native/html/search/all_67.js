var searchData=
[
  ['getdefaultscreeninfo',['getDefaultScreenInfo',['../classknoxremotedesktop_1_1IRemoteDesktop.html#aafef444b0d8af3044e790932648cec3b',1,'knoxremotedesktop::IRemoteDesktop']]],
  ['getframebufinfo',['getFrameBufInfo',['../classknoxremotedesktop_1_1IRemoteDesktop.html#a57d5432823adfd7cfb72441469ccc98e',1,'knoxremotedesktop::IRemoteDesktop']]],
  ['getinstance',['getInstance',['../classknoxremotedesktop_1_1IRemoteDesktop.html#a86eefbec946d605470af069999763f74',1,'knoxremotedesktop::IRemoteDesktop']]],
  ['getscreeninfo',['getScreenInfo',['../classknoxremotedesktop_1_1IRemoteDesktop.html#ae9a1e6863bfc2affad4462bc0a29914a',1,'knoxremotedesktop::IRemoteDesktop']]],
  ['getscreenpixelformatinfo',['getScreenPixelFormatInfo',['../classknoxremotedesktop_1_1IRemoteDesktop.html#a700dee2f575609a933a53d7ab10480e4',1,'knoxremotedesktop::IRemoteDesktop']]],
  ['greenlength',['greenlength',['../structknoxremotedesktop_1_1PixelFormatDetail.html#a87f98032962d81ee015a6a0c56ec6290',1,'knoxremotedesktop::PixelFormatDetail']]],
  ['greenoffset',['greenoffset',['../structknoxremotedesktop_1_1PixelFormatDetail.html#ab334f70ccc320d17dc86a28730954964',1,'knoxremotedesktop::PixelFormatDetail']]]
];
