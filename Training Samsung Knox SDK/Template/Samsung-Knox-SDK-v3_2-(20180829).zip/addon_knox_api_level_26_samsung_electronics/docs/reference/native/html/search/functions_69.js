var searchData=
[
  ['init',['init',['../classknoxremotedesktop_1_1IRemoteDesktop.html#a7bed40d98c61713a69cf1dad8b37beae',1,'knoxremotedesktop::IRemoteDesktop']]]
];
