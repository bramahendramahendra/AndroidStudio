var searchData=
[
  ['dirtyregion',['DirtyRegion',['../classknoxremotedesktop_1_1DirtyRegion.html',1,'knoxremotedesktop']]]
];
