var searchData=
[
  ['numrects',['numRects',['../classknoxremotedesktop_1_1DirtyRegion.html#a433b848a889223e6b404cec9e8db0c7d',1,'knoxremotedesktop::DirtyRegion']]]
];
